#ifndef  KEYBOARD_H
#define KEYBOARD_H

#include <windows.h>
class keyboard {
private:
	
public:
	static int check_kcy();
};

#endif

