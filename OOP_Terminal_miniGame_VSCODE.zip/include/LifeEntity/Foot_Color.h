#ifndef FOOT_COLOR
#define FOOT_COLOR


#endif