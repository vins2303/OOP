#pragma once
#include<iostream>
#include <string>
#include "Map_object.h"

using std::string;

namespace Figure_Rect {
	bool isOverlap( Map_object rc1,  Map_object rc2); 
};