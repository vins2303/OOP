#include "../../include/Map/Map.h"


void Map::getObject(string _Map_name){
	ifstream file("Image\\Map_object\\"+_Map_name+".txt");
	Map_object *obj;
	string name;
	int type;
	int x,y,width,heigh;
	while(!file.eof()){
		file >> name >> type >>x>>y>>width>>heigh;
		setMapType(x,y,width,heigh, objectType(type));
		obj = new Map_object(name, objectType(type), x,y,width,heigh);
		object.push_back(obj);
	}
	file.close();
}


Map::Map(string _Map_name, int _width, int _high):width(_width), high(_high), Map_name(_Map_name){
	MapType = new objectType*[_high];
	for (int i = 0; i < _high; i++)
		MapType[i] = new objectType[_width];

	getObject(_Map_name);
}

Map::~Map() {
	for (int i = 0; i < high; i++)
		delete[] MapType[i];
	delete[] MapType;
	for(vector<Map_object*>::iterator it = object.begin();it!=object.end();it++)
		delete *it;
	object.clear();
}

objectType Map::getMap(int _x, int _y) {
	return MapType[_y][_x];
}

objectType** Map::getMap() {
	return MapType;
}

Map Map::setMapType(int _x, int _y, objectType _object) {
	MapType[_y][_x] = _object;
	return *this;
}

Map Map::setMapType(int _x, int _y, int width, int heigh, objectType _object){
	for(int i=_y;i<_y+heigh;i++)
		for(int j=_x;j<_x+width;j++)
			setMapType(j,i,_object);
	return *this;
}


int Map::getWidth() { return width; }
int Map::getHigh()  { return high; }

Map Map::addObject(Map_object *obj){
	object.push_back(obj);
	return *this;
}

Map Map::showObject(){
	showWall();
	for(vector<Map_object*>::iterator it = object.begin(); it!=object.end();it++){
		Draw::show((*it)->getX(), (*it)->getY(),(*it)->getImage());
	}
	return *this;
}

Map Map::showWall(){
	Draw::setXY(0,0);

	for (int i = 0; i < MAP_WIDTH_DEF/2 + 1; i++)
		cout << "＝";
	//cout << "▛";
	Draw::setXY(0, 42);
	for (int i = 0; i < MAP_WIDTH_DEF / 2 + 1; i++)
		cout << "＝";

	for (int i = 1; i < MAP_HIGH_DEF; i++) {
		Draw::setXY(0, i);
		cout << "∥";
		Draw::setXY(102, i);
		cout << "∥";
	}
	return *this;
}