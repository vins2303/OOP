#include <iostream>
#include <fstream>
#include <ctime>
#include "namegenerator.h"

CNameGenerator::CNameGenerator (){
	srand (time(NULL));
}
void CNameGenerator::load_data (){
	load_familyname ();
	load_firstname();
}

void CNameGenerator::load_familyname (){
	ifstream fin;
	fin.open ("familyname.txt");
	if (!fin){
		cout << "familyname.txt cannot be opened" << endl;
		system("pause");
		exit(0);
	} 
	string name;
	while (fin >> name){		
		familyname.push_back (name);
	}
	fin.close ();
}

void CNameGenerator::load_firstname (){
	ifstream fin;
	fin.open ("firstname.txt");
	if (!fin){
		cout << "firstname.txt cannot be opened" << endl;
		system("pause");
		exit(0);
	} 
	string name;
	while (fin >> name){		
		firstname.push_back (name);
	}
	fin.close ();
}

void CNameGenerator::dump (){
	cout << "Family Name:" << endl;
	for (vector<string>::iterator it = familyname.begin (); it != familyname.end (); it++){
		cout << (*it) << endl;
	}
	cout << "First Name:" << endl;
	for (vector<string>::iterator it = firstname.begin (); it != firstname.end (); it++){
		cout << (*it) << endl;
	}
}

string CNameGenerator::rand_familyname (){
	int size = familyname.size ();
	if (size != 0){
		return (familyname [rand () % size]);
	} else
		return string();
}

string CNameGenerator::rand_firstname (){
	int size = firstname.size ();
	if (size != 0){
		return (firstname [rand () % size]);
	} else
		return NULL;
}

string CNameGenerator::new_name (){	
	bool found;
	string new_name;
	while (1){
		new_name = rand_familyname ();
		new_name += rand_firstname ();
		if (rand () % 2 == 0)
			new_name += rand_firstname ();
		found = false;		
		for (vector<string>::iterator it = generated_name.begin (); it != generated_name.end (); it++){
			if (new_name == (*it)){
				found = true;
				break;
			}
		}
		if (found == false){
			generated_name.push_back (new_name);
			return new_name;
		}			
	}
}