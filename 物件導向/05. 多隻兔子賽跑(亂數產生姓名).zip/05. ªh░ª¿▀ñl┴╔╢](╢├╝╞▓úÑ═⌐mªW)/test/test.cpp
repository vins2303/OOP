#include <iostream>
#include <ctime>
#include <string>
#include <vector>
#include <windows.h>
#include "namegenerator.h"
using namespace std;

#define MAXJUMPCAP 100
#define MAXLENGTH 1000
#define PERLEN 50

class CRabbit {
public:
	CRabbit (string in_name, int maxjump){		
		name = in_name;
		capa_jump = (rand () % maxjump) + 1;		
		location = 0;
	};
	int Run(){
		location += rand() % (capa_jump + 1);
		return location;
	}
	void showinfo (){
		cout << "Rabbit Info: (" << name << ", " << capa_jump << ")" << endl;
	};
	void showlocation (){
		showinfo ();
		cout << location <<":\t";
		if (location > MAXLENGTH)
			location = MAXLENGTH;
		for (int k = 0; k < location / PERLEN; k++)
			cout << "#";
		for (int k = location / PERLEN; k < MAXLENGTH / PERLEN; k++)
			cout << " ";
		cout << "|";
		cout << endl;		
	};
private:
	string name;
	int capa_jump;
	int location;
};

void main (){	
	CNameGenerator generator;
	generator.load_data ();
	vector <CRabbit *> rabbits;
	int num_rabbits;
	cin >> num_rabbits;	
	CRabbit *myrabbit;
	string rabbit_name;
	for (int i = 0; i < num_rabbits; i++){
		rabbit_name = generator.new_name ();
		myrabbit = new CRabbit(rabbit_name, MAXJUMPCAP);
		rabbits.push_back (myrabbit);
	}
	for (vector <CRabbit *>::iterator it = rabbits.begin (); it != rabbits.end (); it++){
		(*it)->showinfo ();
	}

	Sleep(1000);
	system("cls");

	bool terminate = false;
	int location;
	while (!terminate){	
		for (vector <CRabbit *>::iterator it = rabbits.begin (); it != rabbits.end (); it++){		
			location = (*it)->Run();
			(*it)->showlocation ();
			if (location >= MAXLENGTH)
				terminate = true;
		}
		if (!terminate){
			Sleep(1000);
			system("cls");
		}		
	}	
	system ("pause");

}