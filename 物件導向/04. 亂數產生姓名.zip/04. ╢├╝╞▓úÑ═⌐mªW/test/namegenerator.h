#ifndef NAMEGENERATOR_H
#define NAMEGENERATOR_H

#include <string>
#include <vector>
using namespace std;

class CNameGenerator
{
public:
	CNameGenerator ();
	void load_data ();
	void load_familyname ();
	void load_firstname ();
	void dump ();
	string rand_familyname ();
	string rand_firstname ();
	string new_name ();
private:
	vector<string> familyname;
	vector<string> firstname;
	vector<string> generated_name;
};

#endif