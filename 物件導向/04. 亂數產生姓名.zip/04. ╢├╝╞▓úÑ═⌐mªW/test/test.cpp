#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "namegenerator.h"
using namespace std;

void ask_for_random_name (CNameGenerator &gen)
{
	int name_num;
	cin >> name_num;
	while (name_num > 0){				
		for (int i = 0; i < name_num; i++){
			cout << gen.new_name () << endl;
		}
		cin >> name_num;
	}
}

void main (int argc, char** argv){
	CNameGenerator generator;
	generator.load_data ();	
	ask_for_random_name (generator);	
	system("pause");
}