#include<iostream>
#include <string>
#include <algorithm>
#include <iomanip>
using namespace std;

class Matrix {
	friend ostream &operator<< (ostream &, const Matrix &);
	friend istream &operator>> (istream &, Matrix &);
public:
	Matrix (int inr = 10, int inc = 10){
		row = inr; col = inc; 
		data = new int*[row];
		for(int i = 0; i < row; i++)
			data[i] = new int[col];	
		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				data [i][j] = 0;
	}
private:
	int row, col;
	int **data;		
};

ostream &operator<< (ostream &output, const Matrix &m){	
	for (int i = 0; i < m.row; i++){
		if (m.row == 1)
			output << "[ ";
		else if (i == 0)
			output << "/ ";
		else if (i == m.row - 1)
			output << "\\ ";
		else
			output << "| ";

		for (int j = 0; j < m.col; j++){
			output << m.data [i][j] << " ";			 
		}
		if (m.row == 1)
			output << "]";
		else if (i == 0)
			output << "\\";
		else if (i == m.row - 1)
			output << "/";
		else
			output << "|";
		output << endl;
	}
	
	return output;
}

istream &operator>> (istream &input, Matrix &m){	
	int indata;
	for (int i = 0; i < m.row; i++){
		for (int j = 0; j < m.col; j++){
			input >> indata;
			m.data [i][j] = indata;
		}
	}

	return input;
}

void main(){

	int row, col;

	cin >> row >> col;
	Matrix *m;		
	m  = new Matrix (row, col);
	cin >> *m;
	cout << *m;

	system("pause");
}
