#ifndef MONSTER_H
#define MONSTER_H

#include "LifeEntity.h"

class CMonster : public CLifeEntity {
public:
	CMonster (int initHP = 0, int initSP = 0, int initrough = 0);
	int getRough ();
	int physicaldamage ();	
	virtual int attack (CLifeEntity *);
	virtual int defense (CLifeEntity *);
private:
	int RoughDegree;
};

#endif