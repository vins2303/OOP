#include <iostream>
#include "Monster.h"

using namespace std;
CMonster::CMonster (int initHP, int initSP, int initrough) : CLifeEntity (initHP,initSP,"�Ǫ�"), RoughDegree(initrough) {	
	cout << "one monster is created with <HP, SP, rough> = <" << initHP << ", " << initSP << ", " << initrough << ">" << endl;

}

int CMonster::getRough (){
	return RoughDegree;
}

int CMonster::physicaldamage (){
	return (rand () % getSP () + getRough ());
}

int CMonster::attack (CLifeEntity *l){
	int damage = physicaldamage () - l->defense (l); 
	if (damage > l->getHP ())
		damage = l->getHP ();

	l->gethurt (damage);
	
	if (damage > 0){
		cout << this->getname () << " ��ŧ�ӨӡA�y�� " << l->getname () << " " << damage << " ��l��" <<endl;			
	} else {
		cout << this->getname () << " ��ŧ�ӨӡA���O " << l->getname () << " ���`���B�A�]�����פF����" <<endl;
	}
	return (damage);
}

int CMonster::defense (CLifeEntity *l){
	return 0;		
}