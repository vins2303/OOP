#include "LifeEntity.h"

CLifeEntity::CLifeEntity (int initHP, int initSP, string initname){
	maxSP = SP = initSP;
	maxHP = HP = initHP;
	Name = initname;
	weapon = NULL;
}

void CLifeEntity::setInitSPHP (int initHP, int initSP){
	maxSP = SP = initSP;
	maxHP = HP = initHP;	
}

void CLifeEntity::setHP (int inHP){
	HP = inHP > maxHP ? maxHP : inHP;	
}

void CLifeEntity::addHP (int inHP){
	HP = (inHP+HP) > maxHP ? maxHP : (HP+inHP);	
}

void CLifeEntity::addSP (int inSP){
	SP = inSP+SP;	
}

void CLifeEntity::delSP (int inSP){
	SP -= inSP;	
}

int CLifeEntity::getHP (){
	return (HP > 0 ? HP : 0);	
}

int CLifeEntity::getMAXHP (){
	return (maxHP);	
}

int CLifeEntity::getSP (){
	return SP;	
}

int CLifeEntity::getMAXSP (){
	return (maxSP);	
}

bool CLifeEntity::isdead (){
	return (HP<=0);
}

int  CLifeEntity::gethurt (int hurt){
	if (hurt > HP)
		setHP(0);
	else if (hurt > 0)
		setHP(HP - hurt);
	return HP;
}

string CLifeEntity::getname (){
	return Name;
}

void CLifeEntity::setname (string inname){
	Name = inname;	
}
