
#ifndef DEF_H
#define DEF_H

enum {
	efood = 1,
	eweapon
};

#endif