#ifndef FIGHTER_H
#define FIGHTER_H

#include "LifeEntity.h"

#define FIGHTER_MAXHP 100
#define FIGHTER_MAXSP 100
#define FIGHTER_MAXLUCKY 20

class CFood;
class CBag;
class CItem;

class CFighter : public CLifeEntity {
public:
	CFighter (int initHP = 0, int initSP = 0, int initLucky = 0);
	~CFighter();
	int getLucky ();
	int physicaldamage ();	
	virtual int attack (CLifeEntity *);
	virtual int defense (CLifeEntity *);	
	void captureItem (CItem *);
	int showAllBagItems ();
	bool useBagItems (int no);
private:
	int Lucky;
	CBag *bag;
};

#endif