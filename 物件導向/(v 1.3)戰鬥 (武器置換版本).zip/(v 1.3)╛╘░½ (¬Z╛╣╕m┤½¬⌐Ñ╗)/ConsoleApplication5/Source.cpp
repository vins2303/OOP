#include <iostream>
//#include <fstream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
#include "Fighter.h"
#include "Monster.h"
#include "food.h"
#include "ItemData.h"
#include "GlobalInfo.h"
using namespace std;

#define MAXBARLEN 40

void askforbaglist (CFighter *f){
	int num = f->showAllBagItems ();
	if (num == 0)
		return;
	cout << f->getname () << " �ݭn�ϥέI�]���~��?\n0 --> No, Others --> Yes, �ϥΤ����~�s��: ";
	int selection;
	cin >> selection;
	if (selection){		
		if (!f->useBagItems (selection))
			cout << "�L���ﶵ�s�b" << endl;
	}
}

CMonster *MonsterSelection (CFighter *f){
	int selection;
	askforbaglist (f);
	cout << "�п�ܩǪ�����: 1. �T�@ 2. �j�@ 3. �r�@ 4. �䦺�@ " << endl;
	cin >> selection;
	int m_MaxHP, m_MaxSP, m_MaxRough;
	switch (selection){		
		case 1:
			m_MaxHP = f->getMAXHP () / 2;
			m_MaxSP = f->getMAXSP () / 2;
			m_MaxRough = (int)(f->getMAXHP () * 0.1);
			break;
		case 2:
			m_MaxHP = f->getMAXHP ();
			m_MaxSP = f->getMAXSP ();
			m_MaxRough = (int)(f->getMAXHP () * 0.2);
			break;
		case 3:
			m_MaxHP = (int)(f->getMAXHP () * 1.5);
			m_MaxSP = (int)(f->getMAXSP () * 1.2);
			m_MaxRough = (int)(f->getMAXHP () * 0.2);
			break;
		default:
			m_MaxHP = f->getMAXHP () * 2;
			m_MaxSP = f->getMAXSP () * 2;
			m_MaxRough = (int)(f->getMAXHP () * 0.5);			
	}
	CMonster *m  = new CMonster(m_MaxHP, m_MaxSP, m_MaxRough);
	system ("CLS");
	return m;
}

void bloodbarshow (int maxhp, int hp){		
		cout <<  "HP     |";
		float hpslotlen = (float)maxhp / MAXBARLEN;
		int numhp = (int)ceil(hp / hpslotlen);
		for (int i = 0; i < numhp; i++){
			cout <<"#";
		}
		numhp = (int)floor((maxhp- hp) / hpslotlen);
		for (int i = 0; i < numhp; i++){
			cout <<" ";
		}
		cout << "|" << endl;
}

void fightstatus (CMonster *m, CFighter *f){
		cout << endl << f->getname () << endl;
		bloodbarshow (f->getMAXHP (), f->getHP ());
		cout << m->getname () << endl;
		bloodbarshow (m->getMAXHP (), m->getHP ());
		cout << endl;
}

void fightshow (CMonster *m, CFighter *f){
		fightstatus (m, f);
		cout << "�z�ѤU " << f->getHP () << "�w��" << endl;
		Sleep (1000);		
}

void startfight (CMonster *m, CFighter *f){
	int f_damage = 0, s_damage = 0;
	CLifeEntity *first, *second;
	int whofirst;
	while (!m->isdead () && !f->isdead()){

		whofirst = rand () % 2;
		if (whofirst == 0){
			cout << "�Ǫ��m�o�����A���X��ˤH" << endl;
			first = (CLifeEntity *) m;
			second = (CLifeEntity *) f;
		} else {
			cout << "�A�m�o�����A���X��ˤH" << endl;
			first = (CLifeEntity *) f;
			second = (CLifeEntity *) m;	
		}

		s_damage = first->attack (second);		
		if (second->isdead()){
			whofirst == 0 ? fightshow ((CMonster *)first, (CFighter *)second) : fightshow ((CMonster *)second, (CFighter *)first);
			break;
		}

		f_damage = second->attack (first);		
		whofirst == 0 ? fightshow ((CMonster *)first, (CFighter *)second) : fightshow ((CMonster *)second, (CFighter *)first);
	}
	if (m->isdead () && !f->isdead ()){
		cout << "�Ǫ��w���A�q�Ǫ����W���U�_��" << endl;		
		CItemData *id = CGlobalInfo::itm_data;			
		f->captureItem (id->getRand ());		
		//f->showAllBagItems ();
	}
}

CItemData *CGlobalInfo::itm_data = new CItemData;

void Initialize (){
	srand((unsigned int)time(NULL));
	CGlobalInfo::itm_data->Initialize ();
}

int main(){		
	Initialize ();
	CFighter fighter;	
	while (!fighter.isdead ()){
		CMonster *m = MonsterSelection (&fighter);
		if (m){
			fightstatus (m, &fighter);
			cout << endl << endl << "�԰��}�l" << endl  << endl;
			startfight (m, &fighter);
			delete m;
		} else
			cout << "No monster generated" << endl;
	}
	cout << "Game Over!!!" << endl;
	system("pause");
	return 0;
}

