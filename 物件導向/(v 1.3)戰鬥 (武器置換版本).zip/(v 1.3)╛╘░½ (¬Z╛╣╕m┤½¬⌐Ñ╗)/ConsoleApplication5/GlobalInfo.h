
#ifndef GLOBALINFO_H
#define GLOBALINFO_H


class CItemData;

class CGlobalInfo {
public:
	static CItemData *itm_data;	
};

#endif